﻿namespace Postman_clone.Data
{
    public class RestModel
    {
        public string? Action { get; set; }
        public string? Url { get; set; }
        public string? Body { get; set; }
        public string? Response { get; set; }
        public string? buttonText { get; set; }
    }
    public class Todo
    {
        public int id { get; set; }
        public string text { get; set; }
        public bool done { get; set; }
    }
}
